require('@babel/register');
({
    ignore: /node_modules/
});
require('@babel/polyfill');

const WalletProvider = require('./src/wallet-provider');


let mnemonic = 'grid problem oppose venture strike crawl rifle unit gesture cover army gift'; 
let testAccounts = [
"0xa0f3d6c4950dba15c42aec42d470f13d19872d07e4518983c41ec73b8173f544",
"0x00c3c34aa4571dea4edb5886145d9f40a2519ac65abbd729541939b61ec6912e",
"0x16f1cf3e2ba01a7fde4de358912f647d4f52817858ba1330143a0762bf0d15ca",
"0x6be28d225e6334722c1622f3e187f7f6fbf2715a72c1906e176eefda29076816",
"0xbf9d465e50c4c90b9766eef6cb3401b4f32619cd76c90bd6b44552f40059e42d",
"0x1bd0bcc0dae65789bd47d69945da8c84c0dfeebfabc1dbb4aa57a3be2e099c0f",
"0x338e9e86b5e82b3391d291104aa7ce7c3f36b93fcdcc92dda1cbab65079bf7e9",
"0x538a26fb22cde5cb182250bdb7d93a39d0c579105d5c3e4f246da7445b6985d8",
"0x4136e80ce19dce25d007a997a0f7d5a57d2529b12379cf97c4c064328a5b61c5",
"0x0f055bad08e35d251f73822ba917d427ef94f0b71a24e1ec29141b43d51b02cf"
]; 
let devUri = 'https://test.confluxrpc.org/v2';
let host = devUri.replace('http://','').replace('https://','');
let privateKeys = new WalletProvider(mnemonic, 10).privateKeys;

module.exports = {
    testAccounts,
    mnemonic,
    networks: {
        development: {
            uri: devUri,
            network_id: '*',
            host,
            port: 80,
            type: "conflux",
            privateKeys,
            walletProvider: () => new WalletProvider(mnemonic, 10)
        }
    },
    compilers: {
        solc: {
            version: '^0.8.0'
        }
    }
};


